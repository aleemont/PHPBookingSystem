import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
/**
 * Una semplice finestra con:
 * Una casella di testo
 * Un'area di testo (non editabile)
 * Due pulsanti: uno per generare la sequenza e scriverla nell'area di testo
 * ed uno per cancellare il contenuto dell'area di testo
 * 
 * @author Luciano Schiavone 
 * @version 19.12.2019
 */
public class FiboFrame extends JFrame
{
    //Componenti grafici
    JTextField tf;
    JTextArea ta;
    JButton scrivi,cancella, aggiungi;
    JPanel p1,p2,p3,p4;
    JScrollPane sp;
    JLabel l;
    /**
     * Costruttore degli oggetti di classe  FiboFrame
     */
    public FiboFrame()
    {
        initComponent();
    }

    private void initComponent()
    {
        //Istanzio gli elementi
        
        tf = new JTextField(5);
        ta = new JTextArea(7,27);
        sp = new JScrollPane(ta);
        scrivi = new JButton("Scrivi");
        cancella = new JButton("Cancella");
        aggiungi = new JButton("Aggiungi");
        p1 = new JPanel();
        p2 = new JPanel();
        p3 = new JPanel();
        p4 = new JPanel();
        l = new JLabel();
        String s = "Scrivi il numero";
        //Definizioe layout
        ta.setEditable(false);
        sp.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED);
        sp.getVerticalScrollBar().setUnitIncrement(60);
        sp.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        sp.getVerticalScrollBar().setUnitIncrement(10);
        sp.setMinimumSize(new Dimension(500, 0));
        this.setLayout(new BorderLayout());
        l.setText(s);
        p4.setLayout(new FlowLayout());
        p4.add(l);
        p4.add(tf);
        p1.setLayout(new FlowLayout(FlowLayout.LEFT));
        p1.add(p4);
        p2.setLayout(new GridLayout(1,2));
        p2.add(scrivi);
        p2.add(cancella);
        p2.add(aggiungi);
        p3.setLayout(new FlowLayout(FlowLayout.LEFT));
        p3.add(p2);
        this.add(p1, BorderLayout.NORTH);
       // this.add(ta,BorderLayout.CENTER);
        this.add(sp);
        this.add(p3,BorderLayout.SOUTH);
        //Registro listener
        scrivi.addActionListener(new Scrivi());
        cancella.addActionListener(new Canc());
        aggiungi.addActionListener(new Aggiungi());
        //Operazioni finali
        //this.getContentPane().add(sp);
        setSize(new Dimension(300,300));
        setTitle("Successione di Fibonacci");
        setResizable(false);
        setLocation(new Point(200,200));
        setVisible(true);
        this.getContentPane().add(sp);
    }
    
    class Canc implements ActionListener
    {
        public void actionPerformed(ActionEvent e)
        {
            tf.setText("");
            ta.setText("");
        }
    }
    
    class Scrivi implements ActionListener
    {
        public void actionPerformed(ActionEvent e)
        {
            ta.setText("");
            String s = tf.getText();
            try{
                int a = 0;
                int b = 1;
                int n = Integer.parseInt(s);
                for (int i=0; i<n; i++)
                {
                    ta.append(b+"\n");
                    int c = a + b;
                    a = b;
                    b = c;
                }
            }
            catch (NumberFormatException nfe)
            {ta.setText("Errore! Inserire un numero intero");}
            finally {
                tf.setText("");
            }
        }
    }
    
    class Aggiungi implements ActionListener
    {       
        public void actionPerformed(ActionEvent e)
        {
            try
            {
                File Fibonacci = new File("Fibonacci.txt");
                FileWriter fw = new FileWriter(Fibonacci);
                BufferedWriter fOut = new BufferedWriter(fw);
                
                try
                {
                    fOut.write(ta.getText());
                }
                catch(Exception x){}
                fOut.flush();
                fOut.close();
            }
            catch(IOException ioe){}
        }
    }
}
 
