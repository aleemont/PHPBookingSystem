public class mainFibo
{
    public static void main(String args[])
    {
        FiboFrame myFrame1 = new FiboFrame();
        CollatzFrame myFrame2 = new CollatzFrame();
    }
}
