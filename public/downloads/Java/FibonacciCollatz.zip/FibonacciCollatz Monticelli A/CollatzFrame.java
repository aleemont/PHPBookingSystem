import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
/**
 * Una semplice finestra con:
 * Una casella di testo
 * Un'area di testo (non editabile)
 * Due pulsanti: uno per generare la sequenza e scriverla nell'area di testo
 * ed uno per cancellare il contenuto dell'area di testo
 * 
 * @author Luciano Schiavone 
 * @version 19.12.2019
 */
public class CollatzFrame extends JFrame
{
    //Componenti grafici
    JTextField tf;
    JTextArea ta;
    JButton scrivi,cancella,aggiungi;
    JPanel p1,p2,p3,p4;
    JScrollPane sp;
    JLabel l;
    /**
     * Costruttore degli oggetti di classe  CollatzFrame
     */
    public CollatzFrame()
    {
        initComponent();
    }

    private void initComponent()
    {
        //Istanzio gli elementi
        tf = new JTextField(5);
        ta = new JTextArea();
        scrivi = new JButton("Scrivi");
        cancella = new JButton("Cancella");
        aggiungi = new JButton("Aggiungi");
        p1 = new JPanel();
        p2 = new JPanel();
        p3 = new JPanel();
        p4 = new JPanel();
        sp = new JScrollPane(ta);
        l = new JLabel();
        String s = "Scrivi il numero";
        sp.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED);
        sp.getVerticalScrollBar().setUnitIncrement(60);
        sp.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        sp.getVerticalScrollBar().setUnitIncrement(10);
        sp.setMinimumSize(new Dimension(500, 0));
        //Definizione layout
        l.setText(s);
        ta.setEditable(false);
        this.setLayout(new BorderLayout());
        p4.setLayout(new FlowLayout());
        p4.add(l);
        p4.add(tf);
        p1.setLayout(new FlowLayout(FlowLayout.LEFT));
        p1.add(p4);
        p2.setLayout(new GridLayout(1,2));
        p2.add(scrivi);
        p2.add(cancella);
        p2.add(aggiungi);
        p3.setLayout(new FlowLayout(FlowLayout.LEFT));
        p3.add(p2);
        this.add(p1, BorderLayout.NORTH);
        //this.add(ta,BorderLayout.CENTER);
        this.add(sp);
        this.add(p3,BorderLayout.SOUTH);
        //Registro listener
        scrivi.addActionListener(new Scrivi());
        cancella.addActionListener(new Canc());
        aggiungi.addActionListener(new Aggiungi());
        //Operazioni finali
        setSize(new Dimension(300,300));
        setTitle("Successione di Collatz");
        setResizable(false);
        setLocation(new Point(450,200));
        setVisible(true);
    }
    class Canc implements ActionListener
    {
        public void actionPerformed(ActionEvent e)
        {
            tf.setText("");
            ta.setText("");
        }
    }
    class Scrivi implements ActionListener
    {
        public void actionPerformed(ActionEvent e)
        {
            ta.setText("");
            String s = tf.getText();
            try{
                int num = Integer.parseInt(s);
                do{
                    ta.append(num + "\n");
                    if (num%2==0)
                        num = num/2;
                    else
                        num = 3*num+1;
                } while (num!=1);
                ta.append(num + "\n");
            }
            catch (NumberFormatException nfe)
            {}
        }
    }
    class Aggiungi implements ActionListener
    {       
        public void actionPerformed(ActionEvent e)
        {
            try
            {
                File Collatz = new File("Collatz.txt");
                FileWriter f = new FileWriter(Collatz);
                BufferedWriter fOut = new BufferedWriter(f);   
                try
                {
                    fOut.write(ta.getText());
                }
                catch(Exception x){}
                fOut.flush();
                fOut.close();
            }
            catch(IOException ioe){}
        }
    }
}

 
